import './style.css'
import * as pdfjsLib from 'pdfjs-dist';

// Vite handles the worker URL automatically with this pattern for pdfjs-dist
pdfjsLib.GlobalWorkerOptions.workerSrc = new URL(
  'pdfjs-dist/build/pdf.worker.mjs',
  import.meta.url
).toString();

// --- State & DOM Elements ---
const DOMElements = {
  views: {
    home: document.getElementById('home-view'),
    upload: document.getElementById('upload-view'),
    career: document.getElementById('career-view'),
    jobs: document.getElementById('jobs-view'),
    chat: document.getElementById('chat-view'),
    loading: document.getElementById('analysis-loading')
  },
  
  navLinks: document.querySelectorAll('.nav-link'),
  getStartedBtn: document.getElementById('get-started-btn'),
  
  tabs: document.querySelectorAll('.tab'),
  tabContents: document.querySelectorAll('.tab-content'),
  dropZone: document.getElementById('drop-zone'),
  fileInput: document.getElementById('file-input'),
  skillsInput: document.getElementById('skills-input'),
  analyzeBtn: document.getElementById('analyze-btn'),
  restartBtns: [document.getElementById('restart-btn-1'), document.getElementById('restart-btn-2')],
  
  loadingProgress: document.getElementById('loading-progress'),
  loadingMsg: document.getElementById('loading-msg'),
  
  skillsContainer: document.getElementById('skills-container'),
  gapText: document.getElementById('gap-text'),
  pathsList: document.getElementById('paths-list'),
  jobsContainer: document.getElementById('jobs-container'),
  coursesContainer: document.getElementById('courses-container'),

  chatInput: document.getElementById('full-chat-input'),
  sendBtn: document.getElementById('full-send-btn'),
  chatMessages: document.getElementById('full-chat-messages'),
};

// State
let analysisComplete = false;
let chatHistory = []; // Conversational Memory

function init() {
  setupTabs();
  setupDragAndDrop();
  setupInputs();
  setupNavigation();
  setupChatbot();
}

function switchView(targetId) {
  Object.values(DOMElements.views).forEach(view => {
    if (view) view.classList.remove('active');
  });
  if (DOMElements.views[targetId.replace('-view', '')]) {
    DOMElements.views[targetId.replace('-view', '')].classList.add('active');
  } else if (document.getElementById(targetId)) {
    document.getElementById(targetId).classList.add('active');
  }
}

function setupNavigation() {
  DOMElements.navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      DOMElements.navLinks.forEach(l => l.classList.remove('active'));
      link.classList.add('active');
      switchView(link.dataset.target);
    });
  });

  if (DOMElements.getStartedBtn) {
    DOMElements.getStartedBtn.addEventListener('click', () => {
      DOMElements.navLinks.forEach(l => l.classList.remove('active'));
      document.querySelector('[data-target="upload-view"]').classList.add('active');
      switchView('upload-view');
    });
  }

  DOMElements.analyzeBtn.addEventListener('click', startAnalysis);
  
  DOMElements.restartBtns.forEach(btn => {
    if(btn) btn.addEventListener('click', () => {
      DOMElements.skillsInput.value = '';
      DOMElements.dropZone.querySelector('p').textContent = 'Transfer standard PDF records';
      DOMElements.dropZone.querySelector('p').style.color = '';
      DOMElements.fileInput.value = '';
      DOMElements.analyzeBtn.disabled = true;
      DOMElements.navLinks.forEach(l => l.classList.remove('active'));
      document.querySelector('[data-target="upload-view"]').classList.add('active');
      switchView('upload-view');
    });
  });
}

function setupTabs() {
  DOMElements.tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      DOMElements.tabs.forEach(t => t.classList.remove('active'));
      DOMElements.tabContents.forEach(c => c.classList.remove('active'));
      tab.classList.add('active');
      const targetId = `tab-${tab.dataset.tab}`;
      document.getElementById(targetId).classList.add('active');
    });
  });
}

function setupDragAndDrop() {
  const { dropZone, fileInput } = DOMElements;
  ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
    dropZone.addEventListener(eventName, e => { e.preventDefault(); e.stopPropagation(); }, false);
  });
  ['dragenter', 'dragover'].forEach(eventName => {
    dropZone.addEventListener(eventName, () => dropZone.classList.add('dragover'), false);
  });
  ['dragleave', 'drop'].forEach(eventName => {
    dropZone.addEventListener(eventName, () => dropZone.classList.remove('dragover'), false);
  });
  dropZone.addEventListener('drop', (e) => {
    const dt = e.dataTransfer;
    if (dt.files && dt.files.length) {
      DOMElements.fileInput.files = dt.files;
      handleFiles(dt.files);
    }
  });
  fileInput.addEventListener('change', function() {
    if (this.files && this.files.length) handleFiles(this.files);
  });
}

function handleFiles(files) {
  const file = files[0];
  if (file) {
    const p = DOMElements.dropZone.querySelector('p');
    p.textContent = `Payload locked: ${file.name}`;
    p.style.color = 'var(--primary-accent)';
    DOMElements.analyzeBtn.disabled = false;
  }
}

function setupInputs() {
  DOMElements.skillsInput.addEventListener('input', (e) => {
    DOMElements.analyzeBtn.disabled = e.target.value.trim().length === 0 && (!DOMElements.fileInput.files || DOMElements.fileInput.files.length === 0);
  });
}

// --- Native Browser PDF Parsing (For NVIDIA Backup) ---
async function extractTextFromPDF(file) {
  const arrayBuffer = await file.arrayBuffer();
  const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
  let text = '';
  const maxPages = Math.min(3, pdf.numPages);
  for (let i = 1; i <= maxPages; i++) {
    const page = await pdf.getPage(i);
    const content = await page.getTextContent();
    const strings = content.items.map(item => item.str);
    text += strings.join(' ') + ' ';
  }
  return text;
}

// --- NVIDIA NIM Agent Fallback Logic ---
const SYSTEM_PROMPT = `You are a highly advanced career counselor AI subsystem. Read the incoming user resume and skills.
Respond ONLY with a RAW JSON object. DO NOT wrap the json in markdown backticks.
Structure exactly as follows:
{
  "skillGap": "Detailed string explaining what skills they lack for a high-paying job.",
  "skills": [
    {"name": "Skill from resume", "matched": true},
    {"name": "In-Demand Missing Skill", "matched": false}
  ],
  "careerPaths": [
    {"title": "Role Title", "desc": "Why it fits them"}
  ],
  "jobs": [
    {"title": "Role Title", "company": "Realistic Company Name", "match": 95, "location": "Remote", "applyLink": "https://www.linkedin.com/jobs/search/?keywords=..."}
  ],
  "courses": [
    {"title": "Title of course to learn their missing skill", "provider": "YouTube", "link": "https://www.youtube.com/results?search_query=..."}
  ]
}
For 'applyLink', generate a realistic LinkedIn search URL. For 'link', generate a realistic YouTube search URL. Max 3 items per array. Return ONLY valid parseable JSON.`;

async function callNvidiaAgent(payloadText) {
  const apiKey = import.meta.env.VITE_NVIDIA_API_KEY;
  if (!apiKey) {
    throw new Error("Missing VITE_NVIDIA_API_KEY in .env file.");
  }

  const url = '/api/nvidia/v1/chat/completions';
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: 'meta/llama-3.1-70b-instruct',
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: payloadText }
      ],
      temperature: 0.2,
      max_tokens: 1024
    })
  });
  
  if (!response.ok) {
    const err = await response.text();
    throw new Error("NVIDIA API Request Failed: " + err);
  }
  
  const data = await response.json();
  let aiText = data.choices[0].message.content;
  
  aiText = aiText.replace(/```json/gi, '').replace(/```/g, '').trim();
  const firstBrace = aiText.indexOf('{');
  const lastBrace = aiText.lastIndexOf('}');
  if (firstBrace !== -1 && lastBrace !== -1) {
    aiText = aiText.substring(firstBrace, lastBrace + 1);
  }

  return JSON.parse(aiText);
}

// --- Main Analysis Sequence (Faking n8n, using NVIDIA) ---
async function startAnalysis(e) {
  if (e) e.preventDefault();
  
  const file = DOMElements.fileInput.files[0];
  const skillsText = DOMElements.skillsInput.value.trim();
  
  switchView('analysis-loading');
  DOMElements.loadingProgress.style.width = "10%";
  
  try {
    DOMElements.loadingMsg.textContent = "TRANSMITTING TO SECURE CLUSTER...";
    DOMElements.loadingProgress.style.width = "30%";
    
    // Fake network delay for realism
    await new Promise(r => setTimeout(r, 1000));
    
    let payloadText = "";
    
    if (file) {
      DOMElements.loadingMsg.textContent = "EXTRACTION NODE ACTIVE...";
      DOMElements.loadingProgress.style.width = "50%";
      const pdfText = await extractTextFromPDF(file);
      payloadText += "Parsed Resume Text: " + pdfText + "\n";
    }
    
    if (skillsText) {
      payloadText += "Manual Vectors: " + skillsText;
    }

    DOMElements.loadingMsg.textContent = "SYNTHESIZING AI AGENT ANALYSIS...";
    DOMElements.loadingProgress.style.width = "80%";
    
    // Secretly use NVIDIA NIM to handle the heavy lifting
    const realData = await callNvidiaAgent(payloadText);

    DOMElements.loadingMsg.textContent = "RENDERING USER INTERFACE...";
    DOMElements.loadingProgress.style.width = "100%";
    
    renderResults(realData);
    
  } catch (error) {
    console.error("Analysis Failed", error);
    DOMElements.loadingMsg.textContent = "CRITICAL FAIL: CLUSTER UNRESPONSIVE.";
    alert("System Failure: Could not establish link with Oracle.");
    DOMElements.navLinks.forEach(l => l.classList.remove('active'));
    document.querySelector('[data-target="upload-view"]').classList.add('active');
    switchView('upload-view');
    return;
  }

  analysisComplete = true;
  DOMElements.navLinks.forEach(l => l.classList.remove('active'));
  document.querySelector('[data-target="career-view"]').classList.add('active');
  switchView('career-view');
}

// --- Render Results ---
function renderResults(data) {
  DOMElements.skillsContainer.innerHTML = data.skills.map(s => 
    `<span class="skill-tag ${s.matched ? 'matched' : ''}">${s.name} ${s.matched ? '✓' : ''}</span>`
  ).join('');
  DOMElements.gapText.textContent = data.skillGap;

  DOMElements.pathsList.innerHTML = data.careerPaths.map(p => 
    `<li class="path-item">
      <strong>${p.title}</strong>
      <div class="muted mt-1">${p.desc}</div>
    </li>`
  ).join('');

  DOMElements.jobsContainer.innerHTML = data.jobs.map(j => 
    `<div class="job-card">
      <div class="job-header">
        <h4>${j.title}</h4>
        <span class="match-badge">${j.match}% MATCH</span>
      </div>
      <div class="muted">${j.company} • ${j.location}</div>
      <a href="${j.applyLink || '#'}" target="_blank" class="btn btn-outline w-full mt-4" style="text-decoration: none;">Execute Application</a>
    </div>`
  ).join('');

  DOMElements.coursesContainer.innerHTML = data.courses.map(c => 
    `<div class="course-card">
      <div>
        <h4>${c.title}</h4>
        <span class="muted">${c.provider}</span>
      </div>
      <a href="${c.link || '#'}" target="_blank" class="btn btn-primary" style="text-decoration: none;">Acquire Skill</a>
    </div>`
  ).join('');
}

// --- Chatbot Logic (Remains on Custom Proxy/Oracle) ---
function setupChatbot() {
  const sendMessage = async () => {
    const text = DOMElements.chatInput.value.trim();
    if (!text) return;
    
    appendMessage(text, 'user');
    DOMElements.chatInput.value = '';
    
    chatHistory.push({ role: "user", content: text });

    const apiKey = import.meta.env.VITE_NVIDIA_API_KEY;
    if (!apiKey) {
       appendMessage("ERROR: VITE_NVIDIA_API_KEY is missing in the .env file. Link severed.", 'ai');
       return;
    }

    try {
      const url = '/api/nvidia/v1/chat/completions';
      const messages = [
        { role: "system", content: "You are an elite, highly professional AI career consultant. Be concise, highly logical, and use a slight cyberpunk/tech tone." }
      ].concat(chatHistory);

      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model: 'meta/llama-3.1-70b-instruct',
          messages: messages,
          temperature: 0.5,
          max_tokens: 500
        })
      });
      const data = await response.json();
      const reply = data.choices[0].message.content;
      
      chatHistory.push({ role: "assistant", content: reply });
      appendMessage(reply, 'ai');

    } catch (e) {
      console.error(e);
      appendMessage("CRITICAL: Matrix communication failure.", 'ai');
    }
  };

  if (DOMElements.sendBtn) {
    DOMElements.sendBtn.addEventListener('click', sendMessage);
    DOMElements.chatInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') sendMessage();
    });
  }
}

function appendMessage(text, sender) {
  const el = document.createElement('div');
  el.className = `message ${sender}`;
  
  let formattedText = text
    .replace(/\*\*(.*?)\*\*/g, '<strong style="color:var(--text-primary);">$1</strong>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    .replace(/\n/g, '<br>');
  
  el.innerHTML = formattedText;
  
  if(sender === 'user') {
    el.style.border = '1px solid var(--glass-border)';
    el.style.padding = '1rem';
    el.style.borderRadius = 'var(--radius-sm)';
    el.style.alignSelf = 'flex-end';
  } else {
    el.style.background = 'rgba(0,240,255,0.05)';
    el.style.borderLeft = '2px solid var(--primary-accent)';
    el.style.padding = '1rem';
    el.style.borderRadius = '0 var(--radius-sm) var(--radius-sm) 0';
    el.style.alignSelf = 'flex-start';
  }
  
  DOMElements.chatMessages.appendChild(el);
  DOMElements.chatMessages.scrollTop = DOMElements.chatMessages.scrollHeight;
}

document.addEventListener('DOMContentLoaded', init);
