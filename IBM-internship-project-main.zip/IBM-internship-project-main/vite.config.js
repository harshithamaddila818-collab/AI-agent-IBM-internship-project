import { defineConfig } from 'vite';

export default defineConfig({
  server: {
    proxy: {
      // Forward /api/nvidia requests to the NVIDIA NIM endpoint
      '/api/nvidia': {
        target: 'https://integrate.api.nvidia.com',
        changeOrigin: true,
        secure: true,
        rewrite: (path) => path.replace(/^\/api\/nvidia/, ''),
      }
    }
  }
});
